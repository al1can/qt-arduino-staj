#include "dialog.h"
#include "./ui_dialog.h"
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QDebug>
#include <QMessageBox>
#include <QProcess>

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);

    connect(ui->send_button, &QPushButton::clicked, this, &Dialog::sendMessage);
    //connect(ui->send_button, &QPushButton::clicked, this, &Dialog::waitForRespond);
    connect(ui->receive_button, &QPushButton::clicked, this, &Dialog::receiveMessage);

    connect(ui->pushButton_step1, &QPushButton::clicked, this, &Dialog::Step1Start);
    connect(ui->pushButton_step2, &QPushButton::clicked, this, &Dialog::Step2Start);
    connect(ui->pushButton_step3, &QPushButton::clicked, this, &Dialog::Step3Start);
    connect(ui->pushButton_step_all, &QPushButton::clicked, this, &Dialog::StepAllStart);


    arduino_is_available = false;
    arduino_port_name = "";

    arduino = new QSerialPort;

    connect(arduino, &QSerialPort::errorOccurred, this, &Dialog::showErrorMessageBox);

    /*
    QProcess *process1 = new QProcess(this);

    process1->start(QString("lsusb"), QIODevice::ReadWrite);

    bool retval = false;
    QByteArray buffer;

    while ((retval = process1->waitForFinished()))
        buffer.append(process1->readAll());

    if (!retval) {
        qDebug() << "Process 2 error:" << process1->errorString();
    }

    qDebug() << buffer;

    qDebug() << "Number of available ports: " << QSerialPortInfo::availablePorts().length();
    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts()) {
        qDebug() << "Has vendor ID: " << serialPortInfo.hasVendorIdentifier();
        if(serialPortInfo.hasVendorIdentifier()) {
            qDebug() << "Vendor ID: " << serialPortInfo.vendorIdentifier();
        }
        qDebug() << "Has Product ID: " << serialPortInfo.hasProductIdentifier();
        if (serialPortInfo.hasProductIdentifier()) {
            qDebug() << "Product ID: " << serialPortInfo.productIdentifier();
        }
    }*/

    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts())
    {
        if (serialPortInfo.hasVendorIdentifier() && serialPortInfo.hasProductIdentifier()){
            if(serialPortInfo.vendorIdentifier() == arduino_uno_vendor_id){
                if(serialPortInfo.productIdentifier() == arduino_uno_product_id) {
                    arduino_port_name = serialPortInfo.portName();
                    qDebug() << "Arduino port name: " + arduino_port_name;
                    arduino_is_available = true;
                }
            }
        }
    }

    if (arduino_is_available) {
        arduino->setPortName(arduino_port_name);
        bool isSuccesfull = arduino->open(QSerialPort::ReadWrite);
        arduino->setBaudRate(QSerialPort::Baud115200);
        arduino->setDataBits(QSerialPort::Data8);
        arduino->setParity(QSerialPort::NoParity);
        arduino->setStopBits(QSerialPort::OneStop);
        arduino->setFlowControl(QSerialPort::NoFlowControl);

        qDebug() << "Arduino configured!";
        qDebug() << "Is arduino open for connection: " << isSuccesfull;
    } else {
        QMessageBox::warning(this, "Port error", "Couldnt find arduino!");
    }

}

Dialog::~Dialog()
{
    if (arduino->isOpen()) {
        arduino->close();
    }

    delete ui;
}

void Dialog::sendMessage()
{
    qDebug() << "Is Arduino open: " << arduino->isOpen();
    qDebug() << "Is Arduino writable: " << arduino->isWritable();

    QStringList values;
    QString message ("");

    if (arduino->isOpen()) {
        values.append(QString::number(ui->spinBox_motorPos->value()));

        values.append(QString::number(ui->spinBox_acceleration->value()));

        values.append(QString::number(ui->spinBox_speed->value()));

        for (int i = 0; i < values.count(); i ++) {
            message.append(values[i]);
            message.append(",");
        }

        arduino->write(message.toStdString().c_str());

        qDebug() <<  "Message is sent! Message: " << message;
    } else {
        qDebug() << "Couldnt write to Serial!";
        QMessageBox::warning(this, "Serial Error", "Couldnt write to Serial!");
    }
}

void Dialog::receiveMessage()
{
    m_readData.remove(0, m_readData.length());

    m_readData.append(arduino->readAll());

    qDebug() << "Received message is : " << m_readData;
    ui->textEdit->setText(m_readData);
}

void Dialog::waitForRespond()
{
    /*
    if (!arduino->waitForReadyRead()) {
        ui->receive_button->setEnabled(false);
    }
    ui->receive_button->setEnabled(true);
    */
}

void Dialog::showErrorMessageBox()
{
    if (arduino->errorString() != "No error")
    {
        QMessageBox::warning(this, "Connection error!", "Can't connect to arduino! Error: " + arduino->errorString());
        QApplication::quit();
    }
}

void Dialog::StepsStart()
{
    QStringList values;
    QString message ("");

    int value = 0;
    int acceleration = 0;
    int speed = 50;

    QPushButton* buttonSender = qobject_cast<QPushButton*>(sender());

    if (buttonSender->objectName() == "pushButton_step1") {
        value = 15;
    } else if (buttonSender->objectName() == "pushButton_step2") {
        value = 25;
    } else if (buttonSender->objectName() == "pushButton_step3") {
        value = 40;
    }

    values.append(QString::number(value));
    values.append(QString::number(acceleration));
    values.append(QString::number(speed));

    for (int i = 0; i < values.count(); i ++) {
        message.append(values[i]);
        message.append(",");
    }

    //arduino->write(message.toStdString().c_str());
    qDebug() <<  "Message is sent! Message: " << message;
}


void Dialog::StepsStart(int value, int acceleration, int speed)
{
    QStringList values;
    QString message ("");;

    values.append(QString::number(value));
    values.append(QString::number(acceleration));
    values.append(QString::number(speed));

    for (int i = 0; i < values.count(); i ++) {
        message.append(values[i]);
        message.append(",");
    }

    arduino->write(message.toStdString().c_str());
    qDebug() <<  "Message is sent! Message: " << message;
}

void Dialog::Step1Start()
{
    StepsStart(15, 0, 50);
}

void Dialog::Step2Start()
{
    StepsStart(30, 0, 50);
}

void Dialog::Step3Start()
{
    StepsStart(50, 0, 50);
    // StepsStart(30, 0, 50);
}

void Dialog::StepAllStart()
{
    Step1Start();
    Step2Start();
    Step3Start();
}
